﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RETO2_Mario_Ximena_Darnnel
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Reto 2 - EDIFICIO ++");
            int[] adultos = new int[5];
            int[] niños = new int[5];
            int suma = 0;
            int sumaA = 0;
            int sumaB = 0;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("El nivel es el " + (i + 1));
                Console.WriteLine("Ingrese el número de adultos en este nivel: ");
                adultos[i] = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Numero de niños en este nivel: ");
                niños[i] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("-----------------------------");
            }
            for (int i = 0; i < 5; i++)
            {
                suma = adultos[i = 0] + adultos[i = 1] + adultos[i = 2] + adultos[i = 3] + adultos[i = 4] + niños[i = 0] + niños[i = 1] + niños[i = 2] + niños[i = 3] + niños[i = 4];
                sumaA = adultos[i = 0] + adultos[i = 1] + adultos[i = 2] + adultos[i = 3] + adultos[i = 4];
                sumaB = niños[i = 0] + niños[i = 1] + niños[i = 2] + niños[i = 3] + niños[i = 4];
            }
            Console.WriteLine("Total de niños que hay: " + sumaA);
            Console.WriteLine("Total de adultos que hay: " + sumaB);
            Console.WriteLine("El total de adultos y niños es " + suma);

            Console.ReadKey();
        }
    }
}
