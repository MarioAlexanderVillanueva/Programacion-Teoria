﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto3_Mario_Darnnel_Ximena
{ 
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Reto 3");
            string[] nivel = new string[5];
            float[] adultos = new float[5];
            float[] niños = new float[5];
            string[] encargados = new string[5];
            float mayor = 0;
            int pos = 0;
            string nombre;
            string masencargados = "";

            for (int f = 0; f < nivel.Length; f++)
            {
                Console.Write("Ingrese el nivel del edificio:");
                nivel[f] = Console.ReadLine();

                Console.Write("Ingrese la cantidad de adultos en ese nivel:");
                string linea;
                linea = Console.ReadLine();
                adultos[f] = float.Parse(linea);

                Console.Write("Ingrese la cantidad de niños en ese nivel:");
                string linea1;
                linea1 = Console.ReadLine();
                niños[f] = float.Parse(linea1);

                Console.Write("Ingrese el nombre del encargados en este nivel:");
                encargados[f] = Console.ReadLine();


            }
                for (int f = 0; f < nivel.Length; f++)
            {
                Console.WriteLine("Numero de  nivel: " + nivel[f] + "");
                Console.WriteLine("Numero de adultos en el nivel: " + adultos[f] + "");
                Console.WriteLine("Numero de  nivel: " + nivel[f] + "");
                Console.WriteLine("Numero de niños en el nivel: " + niños[f] + "");
                Console.WriteLine("Numero de  nivel: " + nivel[f] + "");
                Console.WriteLine("Numero de encargados en el nivel: " + encargados[f] + "");
            }

            for (int f = 0; f < 5; f++)
            {
                if (niños[f] > mayor)
                {
                    
                    mayor = niños[f];
                    pos = f;
                    masencargados = encargados[f];


                }
            }
            Console.WriteLine("El numero de nivel con mayor cantidad de personas es el numero " + nivel[pos]);
            Console.WriteLine("Numero de personas en ese nivel:" + mayor);
            Console.WriteLine("Nombre del encargado con mas niños es:" + masencargados);
            Console.ReadKey();
        } 
     }
}
